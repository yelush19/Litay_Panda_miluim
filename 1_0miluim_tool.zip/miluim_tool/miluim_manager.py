#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
מערכת ניהול תשלומי מילואים - ליטאי ניהול שירותים
כלי ייבוא ועדכון נתונים
"""

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from datetime import datetime
import os
import shutil

# === הגדרות ===
SYSTEM_FILE = r"C:\Projects\LitayPandaMiluim\מערכת_מילואים_מלאה.xlsx"

# צבעי ליטאי
LITAY_GREEN = "#528163"
LITAY_GREEN_DARK = "#2d5f3f"
LITAY_GREEN_LIGHT = "#8dd1bb"
LITAY_BG = "#f5f6fa"

class MiluimManager:
    def __init__(self, root):
        self.root = root
        self.root.title("מערכת מילואים - ליטאי")
        self.root.geometry("500x450")
        self.root.configure(bg=LITAY_BG)
        
        # כותרת
        title = tk.Label(
            root, 
            text="🎯 מערכת ניהול תשלומי מילואים",
            font=("Arial", 18, "bold"),
            bg=LITAY_BG,
            fg=LITAY_GREEN_DARK
        )
        title.pack(pady=20)
        
        subtitle = tk.Label(
            root,
            text="ליטאי ניהול שירותים",
            font=("Arial", 12),
            bg=LITAY_BG,
            fg=LITAY_GREEN
        )
        subtitle.pack()
        
        # מסגרת כפתורים
        btn_frame = tk.Frame(root, bg=LITAY_BG)
        btn_frame.pack(pady=30, padx=40, fill="both", expand=True)
        
        # כפתורים
        self.create_button(btn_frame, "📥 ייבוא קובץ מקאנו", self.import_mecano, 0)
        self.create_button(btn_frame, "💰 ייבוא תשלום ביטוח לאומי", self.import_btl, 1)
        self.create_button(btn_frame, "➕ ייבוא תוספת 40%", self.import_40_percent, 2)
        self.create_button(btn_frame, "🔄 חישוב הפרשים ועדכון", self.calculate_differences, 3)
        
        # סטטוס
        self.status_var = tk.StringVar(value="מוכן לעבודה")
        status = tk.Label(
            root,
            textvariable=self.status_var,
            font=("Arial", 10),
            bg=LITAY_GREEN_LIGHT,
            fg=LITAY_GREEN_DARK,
            pady=10
        )
        status.pack(fill="x", side="bottom")
        
    def create_button(self, parent, text, command, row):
        btn = tk.Button(
            parent,
            text=text,
            font=("Arial", 14),
            bg=LITAY_GREEN,
            fg="white",
            activebackground=LITAY_GREEN_DARK,
            activeforeground="white",
            cursor="hand2",
            command=command,
            height=2
        )
        btn.pack(fill="x", pady=8)
        
    def backup_file(self):
        """יצירת גיבוי של הקובץ"""
        if os.path.exists(SYSTEM_FILE):
            backup_dir = os.path.join(os.path.dirname(SYSTEM_FILE), "גיבויים")
            os.makedirs(backup_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"מערכת_מילואים_גיבוי_{timestamp}.xlsx"
            backup_path = os.path.join(backup_dir, backup_name)
            shutil.copy2(SYSTEM_FILE, backup_path)
            return backup_path
        return None
        
    def import_mecano(self):
        """ייבוא קובץ מקאנו"""
        file_path = filedialog.askopenfilename(
            title="בחר קובץ מקאנו",
            filetypes=[("Excel files", "*.xlsx *.xls")]
        )
        if not file_path:
            return
            
        try:
            self.status_var.set("מייבא קובץ מקאנו...")
            self.root.update()
            
            # קריאת הקובץ
            df = pd.read_excel(file_path)
            
            # גיבוי
            self.backup_file()
            
            # TODO: לוגיקת ייבוא מקאנו
            
            self.status_var.set(f"✅ יובאו {len(df)} רשומות מקאנו")
            messagebox.showinfo("הצלחה", f"יובאו {len(df)} רשומות מקובץ מקאנו")
            
        except Exception as e:
            self.status_var.set("❌ שגיאה בייבוא")
            messagebox.showerror("שגיאה", f"שגיאה בייבוא קובץ מקאנו:\n{str(e)}")
            
    def import_btl(self):
        """ייבוא תשלום ביטוח לאומי"""
        file_path = filedialog.askopenfilename(
            title="בחר קובץ ביטוח לאומי",
            filetypes=[("Excel files", "*.xlsx *.xls *.xla")]
        )
        if not file_path:
            return
            
        try:
            self.status_var.set("מייבא קובץ ביטוח לאומי...")
            self.root.update()
            
            # קריאת הקובץ - שורה 11 היא הכותרות
            df = pd.read_excel(file_path, header=None)
            
            # חילוץ פרטי מנה
            mana_number = df.iloc[2, 1]  # מספר מנה
            payment_date = df.iloc[9, 1]  # תאריך תשלום
            
            # חילוץ נתונים (משורה 12)
            headers = df.iloc[11].tolist()
            data = df.iloc[12:].copy()
            data.columns = headers
            data = data.dropna(subset=['זהות'])
            
            # גיבוי
            self.backup_file()
            
            # טעינת קובץ המערכת
            wb = load_workbook(SYSTEM_FILE)
            ws = wb['3️⃣ תשלומי ב"ל']
            
            # מציאת שורה ריקה ראשונה
            next_row = ws.max_row + 1
            
            # הוספת הנתונים
            added = 0
            for _, row in data.iterrows():
                try:
                    ws.cell(next_row, 1).value = str(row['זהות'])
                    ws.cell(next_row, 2).value = f"{row['שם פרטי']} {row['שם משפחה']}"
                    ws.cell(next_row, 3).value = row['תאריך שרות']
                    ws.cell(next_row, 4).value = row['תאריך סיום שרות']
                    ws.cell(next_row, 5).value = row['סוג תביעה']
                    
                    # ניקוי סימני + ו-
                    tagmul = str(row['תגמול נדרש']).replace('+', '').replace('-', '')
                    pitzuy = str(row['פיצוי %20 למעסיק']).replace('+', '').replace('-', '')
                    
                    ws.cell(next_row, 6).value = float(tagmul) if tagmul and tagmul != '0' else 0
                    ws.cell(next_row, 7).value = float(pitzuy) if pitzuy and pitzuy != '0' else 0
                    ws.cell(next_row, 8).value = 0  # תוספת 40%
                    ws.cell(next_row, 9).value = float(tagmul) if tagmul else 0  # סה"כ לעובד
                    ws.cell(next_row, 10).value = mana_number
                    ws.cell(next_row, 11).value = payment_date
                    ws.cell(next_row, 12).value = os.path.basename(file_path)
                    
                    next_row += 1
                    added += 1
                except Exception as e:
                    print(f"שגיאה בשורה: {e}")
                    continue
            
            # שמירה
            wb.save(SYSTEM_FILE)
            
            self.status_var.set(f"✅ יובאו {added} רשומות מביטוח לאומי (מנה {mana_number})")
            messagebox.showinfo("הצלחה", f"יובאו {added} רשומות\nמנה: {mana_number}\nתאריך: {payment_date}")
            
        except Exception as e:
            self.status_var.set("❌ שגיאה בייבוא")
            messagebox.showerror("שגיאה", f"שגיאה בייבוא:\n{str(e)}")
            
    def import_40_percent(self):
        """ייבוא תוספת 40%"""
        file_path = filedialog.askopenfilename(
            title="בחר קובץ תוספת 40%",
            filetypes=[("Excel files", "*.xlsx *.xls *.xla")]
        )
        if not file_path:
            return
            
        try:
            self.status_var.set("מייבא קובץ תוספת 40%...")
            self.root.update()
            
            # TODO: לוגיקת ייבוא תוספת 40%
            # המבנה דומה אבל צריך לזהות את סוג התביעה
            
            messagebox.showinfo("בקרוב", "פונקציה זו תתווסף בקרוב")
            self.status_var.set("מוכן לעבודה")
            
        except Exception as e:
            self.status_var.set("❌ שגיאה בייבוא")
            messagebox.showerror("שגיאה", f"שגיאה:\n{str(e)}")
            
    def calculate_differences(self):
        """חישוב הפרשים ועדכון סטטוסים"""
        try:
            self.status_var.set("מחשב הפרשים...")
            self.root.update()
            
            # גיבוי
            self.backup_file()
            
            # טעינת קובץ המערכת
            wb = load_workbook(SYSTEM_FILE)
            
            # TODO: לוגיקת חישוב הפרשים
            # 1. קריאת תקופות מילואים
            # 2. קריאת תשלומי ב"ל
            # 3. התאמה לפי ת.ז + תאריכים
            # 4. חישוב: תשלום מעסיק - תגמול ב"ל
            # 5. עדכון דוח מסכם
            
            wb.save(SYSTEM_FILE)
            
            messagebox.showinfo("בקרוב", "פונקציה זו תתווסף בקרוב")
            self.status_var.set("מוכן לעבודה")
            
        except Exception as e:
            self.status_var.set("❌ שגיאה בחישוב")
            messagebox.showerror("שגיאה", f"שגיאה:\n{str(e)}")

def main():
    root = tk.Tk()
    app = MiluimManager(root)
    root.mainloop()

if __name__ == "__main__":
    main()
